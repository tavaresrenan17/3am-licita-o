# Contrato PNCP e filtros nativos

Verificado em 11/09/2026. As tabelas de parâmetros abaixo foram extraídas do [OpenAPI de produção](https://pncp.gov.br/api/consulta/v3/api-docs), título **API PNCP CONSULTA**, versão declarada **1.0**, OpenAPI 3.0.1. A versão 1.0 do contrato não significa que o manual PDF antigo descreva todos os recursos atuais.

## 1. Endereços e política de contrato

- Base pública de consulta: `https://pncp.gov.br/api/consulta`.
- [Swagger funcional](https://pncp.gov.br/api/consulta/swagger-ui/index.html). Remover os dois pontos finais extras do endereço originalmente informado.
- [Manual API Consultas v1.0](https://www.gov.br/pncp/pt-br/pncp/copy_of_manuais/ManualPNCPAPIConsultasVerso1.0.pdf/@@display-file/file): explica campos, datas e identidades, mas contém divergências.
- [Manual Integração v2.6](https://pncp.gov.br/manual/pt-br/latest/): domínios e leitura de detalhes, itens, documentos e histórico, além de operações de manutenção fora deste projeto.

Todos os endpoints deste inventário são GET. As consultas de amostra funcionaram sem credenciais PNCP. Não implementar login PNCP para esses GETs por causa dos serviços de escrita do manual de integração. Usar HTTPS, verificação de certificado e Accept: application/json.

Na divergência, usar contrato corrente junto a testes pequenos e explícitos de comportamento. Não transformar um HTTP 200 isolado em garantia de filtro. Congelar um snapshot do OpenAPI na implementação, comparar periodicamente sua estrutura e exigir revisão quando mudarem parâmetros/limites/campos. Os exemplos de data/hora do OpenAPI podem variar entre downloads; ignorá-los em diffs semânticos.

## 2. Matriz das três listagens principais

| Parâmetro | Publicação | Propostas abertas | Atualização global | Significado e cuidado |
|---|---|---|---|---|
| dataInicial | Obrigatório | Não existe | Obrigatório | Início por publicação ou atualização, conforme rota. |
| dataFinal | Obrigatório | Obrigatório | Obrigatório | AAAAMMDD; semântica de proposta detalhada no arquivo 02. |
| codigoModalidadeContratacao | Obrigatório | Opcional | Obrigatório | Um código do domínio por requisição. |
| codigoModoDisputa | Opcional | Não existe | Opcional | Um código; em proposta filtrar no banco. |
| uf | Opcional | Opcional | Opcional | UF da unidade administrativa, não local de entrega presumido. |
| codigoMunicipioIbge | Opcional | Opcional | Opcional | Município da unidade administrativa; string. |
| cnpj | Opcional | Opcional | Opcional | Órgão originário da contratação; string, preservar letras/zeros. |
| codigoUnidadeAdministrativa | Opcional | Opcional | Opcional | Unidade do órgão; não é nome de unidade. |
| idUsuario | Opcional | Opcional | Opcional | Portal/sistema que publicou, não usuário do seu aplicativo. |
| pagina | Obrigatório | Obrigatório | Obrigatório | Inteiro, começa em 1. |
| tamanhoPagina | Opcional, 10–50 | Opcional, 10–50 | Opcional, 10–50 | Definir explicitamente 50 como ponto de partida. |

Não existe parâmetro nativo documentado nessas três rotas para palavra-chave, objeto, valor mínimo/máximo, situação, SRP, esfera, poder, tipo de instrumento, amparo legal, CNAE, CATMAT/CATSER, benefício ME/EPP, texto de anexo, ordenação customizada ou projeção de campos. Isso não impede filtros locais sobre os campos recebidos/enriquecidos. Não confundir campos de resposta com parâmetros de requisição.

## 3. Inventário completo do OpenAPI de consulta verificado

A lista cobre os 12 paths presentes no snapshot. Os módulos fora de contratações são referência de expansão; não incluí-los automaticamente na carga inicial. Nomes semelhantes variam entre endpoints e devem ser respeitados. Todos os parâmetros não identificados como path são query parameters.

### GET /v1/pca/usuario

Consultar Itens de PCA por Ano do PCA, IdUsuario e Código de Classificação Superior.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `anoPca` | query | Sim | integer; int32 |
| `idUsuario` | query | Sim | integer; int64 |
| `codigoClassificacaoSuperior` | query | Não | string |
| `cnpj` | query | Não | string |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

### GET /v1/pca/atualizacao

Consultar PCA por Data de Atualização Global.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicio` | query | Sim | string |
| `dataFim` | query | Sim | string |
| `cnpj` | query | Não | string |
| `codigoUnidade` | query | Não | string |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

### GET /v1/pca/

Consultar Itens de PCA por Ano do PCA e Código de Classificação Superior.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `anoPca` | query | Sim | integer; int32 |
| `codigoClassificacaoSuperior` | query | Sim | string; comprimento mín. 0; comprimento máx. 100 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

### GET /v1/orgaos/{cnpj}/compras/{ano}/{sequencial}

Consultar Contratação.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `cnpj` | path | Sim | string |
| `ano` | path | Sim | integer; int32 |
| `sequencial` | path | Sim | integer; int32; mín. 1 |

### GET /v1/instrumentoscobranca/inclusao

Consultar Instrumentos de Cobrança por Data de Inclusão.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string |
| `dataFinal` | query | Sim | string |
| `tipoInstrumentoCobranca` | query | Não | integer; int64 |
| `cnpjOrgao` | query | Não | string |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 100 |

### GET /v1/contratos

Consultar Contratos por Data de Publicação.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string |
| `dataFinal` | query | Sim | string |
| `cnpjOrgao` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string |
| `usuarioId` | query | Não | integer; int64 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

### GET /v1/contratos/atualizacao

Consultar Contratos/Empenhos por Data de Atualização Global.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string |
| `dataFinal` | query | Sim | string |
| `cnpjOrgao` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string |
| `usuarioId` | query | Não | integer; int64 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

### GET /v1/contratacoes/publicacao

Consultar Contratações por Data de Publicação.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string |
| `dataFinal` | query | Sim | string |
| `codigoModalidadeContratacao` | query | Sim | integer; int64 |
| `codigoModoDisputa` | query | Não | integer; int32 |
| `uf` | query | Não | string |
| `codigoMunicipioIbge` | query | Não | string |
| `cnpj` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string |
| `idUsuario` | query | Não | integer; int64 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 50 |

### GET /v1/contratacoes/proposta

Consultar Contratações com Recebimento de Propostas Aberto.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataFinal` | query | Sim | string |
| `codigoModalidadeContratacao` | query | Não | integer; int64 |
| `uf` | query | Não | string |
| `codigoMunicipioIbge` | query | Não | string |
| `cnpj` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string; comprimento mín. 1; comprimento máx. 30 |
| `idUsuario` | query | Não | integer; int64 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 50 |

### GET /v1/contratacoes/atualizacao

Consultar Contratações por Data de Atualização Global.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string |
| `dataFinal` | query | Sim | string |
| `codigoModalidadeContratacao` | query | Sim | integer; int64 |
| `codigoModoDisputa` | query | Não | integer; int32 |
| `uf` | query | Não | string |
| `codigoMunicipioIbge` | query | Não | string |
| `cnpj` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string |
| `idUsuario` | query | Não | integer; int64 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 50 |

### GET /v1/atas

Consultar Ata de Registro de Preço por Período de Vigência.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string; Formato: yyyyMMdd |
| `dataFinal` | query | Sim | string; Formato: yyyyMMdd |
| `idUsuario` | query | Não | integer; int64 |
| `cnpj` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string; comprimento mín. 1; comprimento máx. 30 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

### GET /v1/atas/atualizacao

Consultar Atas de Registro de Preço por Data de Atualização Global.

| Parâmetro | Local | Obrigatório | Tipo/limites do OpenAPI |
|---|---|---|---|
| `dataInicial` | query | Sim | string; Formato: yyyyMMdd |
| `dataFinal` | query | Sim | string; Formato: yyyyMMdd |
| `idUsuario` | query | Não | integer; int64 |
| `cnpj` | query | Não | string |
| `codigoUnidadeAdministrativa` | query | Não | string; comprimento mín. 1; comprimento máx. 30 |
| `pagina` | query | Sim | integer; int32; mín. 1 |
| `tamanhoPagina` | query | Não | integer; int32; mín. 10; máx. 500 |

## 4. Envelope e resposta de contratação

As três listagens principais referenciam `PaginaRetornoRecuperarCompraPublicacaoDTO`:

```json
{"data": [], "totalRegistros": 0, "totalPaginas": 0, "numeroPagina": 1, "paginasRestantes": 0, "empty": true}
```

É um exemplo de estrutura, não resposta executada. O total e o número de páginas da fonte descrevem aquela consulta observada; não representam um snapshot imutável. Não há cursor remoto nem token de snapshot documentados nesse contrato. `data` contém os cabeçalhos; não contém a lista completa de itens nem o texto dos documentos.

Campos declarados para cada cabeçalho no snapshot:

- `dataAberturaProposta`
- `dataEncerramentoProposta`
- `informacaoComplementar`
- `processo`
- `objetoCompra`
- `linkSistemaOrigem`
- `justificativaPresencial`
- `srp`
- `amparoLegal`
- `orgaoEntidade`
- `anoCompra`
- `sequencialCompra`
- `dataInclusao`
- `dataPublicacaoPncp`
- `dataAtualizacao`
- `numeroCompra`
- `unidadeOrgao`
- `unidadeSubRogada`
- `orgaoSubRogado`
- `valorTotalHomologado`
- `linkProcessoEletronico`
- `emendaParlamentar`
- `dataAtualizacaoGlobal`
- `modoDisputaId`
- `numeroControlePNCP`
- `modalidadeId`
- `tipoInstrumentoConvocatorioNome`
- `fontesOrcamentarias`
- `usuarioNome`
- `tipoInstrumentoConvocatorioCodigo`
- `situacaoCompraId`
- `modoDisputaNome`
- `modalidadeNome`
- `valorTotalEstimado`
- `situacaoCompraNome`

O órgão vem em `orgaoEntidade` (cnpj, razaoSocial, poderId, esferaId), e a unidade em `unidadeOrgao` (ufNome, codigoUnidade, nomeUnidade, ufSigla, municipioNome, codigoIbge). Guardar também referências de sub-rogação quando presentes. Os filtros de propriedade e localização precisam respeitar a semântica original, sem misturar órgão originário e sub-rogado.

O schema define `situacaoCompraId` como string enum "1"–"4"; as respostas reais de amostra entregaram números. Normalizar de forma controlada, preservar o bruto e não rejeitar todo o lote por essa diferença conhecida. Datas podem vir sem offset. Não inventar dados para campos ausentes/nulos.

O detalhe `RecuperarCompraDTO` inclui campos adicionais como `orcamentoSigilosoCodigo`, `orcamentoSigilosoDescricao` e `existeResultado`. O indicador de sigilo aparece ainda como writeOnly no schema e não deve ser exigido como campo de resposta. A listagem não declara os dois campos de código/descrição de sigilo. Se preço desconhecido/sigiloso afetar elegibilidade, obter detalhe e aplicar a política do arquivo 08; não considerar todo zero como valor conhecido.

## 5. Erros e limites

O contrato declara HTTP 200, 204, 400, 401, 422 e 500. Tratar também falhas de rede, timeout, 429 e 502/503/504 operacionalmente, mesmo sem enumeração no snapshot. **204 deve ser processado antes de tentar ler JSON.** HTML de proxy ou página de erro com status 200 não é lote válido.

Validar datas reais de calendário, início menor ou igual ao fim, página >=1 e tamanho conforme a rota. O OpenAPI não fornece limite máximo universal de intervalo de datas nem quota pública de requisições por segundo. Não afirmar limite de 365 dias, 5 RPS ou outra quota como oficial sem nova evidência. Usar janelas pequenas por decisão operacional, com métricas. Se aparecer limite servidor, registrar a resposta e atualizar o contrato.

Diferenças que não podem se perder:

- `cnpj` em contratações/atas; `cnpjOrgao` em contratos/instrumentos de cobrança.
- `idUsuario` em contratações/atas/PCA por usuário; `usuarioId` em contratos.
- `dataInicio`, `dataFim`, `codigoUnidade` em PCA por atualização; não transplantar os nomes das contratações.
- Máximo 50 nas listagens de contratações; 500 em PCA/atas/contratos; 100 em instrumentos de cobrança no snapshot. Não extrapolar esses limites aos GETs de itens da API de integração.

## 6. Divergências confirmadas

| Tema | Manual de consultas v1.0 | OpenAPI e observação de 11/09/2026 | Decisão |
|---|---|---|---|
| Tamanho de página das contratações | Menciona 500 em trechos das seções 6.3/6.4. | Máximo 50; proposta com 51 retornou 400. | Usar 10–50. |
| Modalidade em proposta | Texto diz opcional, tabela da seção 6.4 diz obrigatória. | required=false; GET sem modalidade retornou 200 com dados. | Permitir ausência nessa rota. |
| Transporte dos filtros | Algumas tabelas dizem cabeçalho. | OpenAPI in=query; exemplos usam URL. | Query string. |
| Sincronização de mudanças | Catálogo antigo sem rotas atuais de atualização. | Existe /contratacoes/atualizacao por atualização global. | Implementar incremental por essa rota. |

Detalhes das observações e fontes: [07_FONTES_E_VALIDACOES.md](07_FONTES_E_VALIDACOES.md). Planejamento e exemplos: [02_PLANEJADOR_DE_BUSCAS.md](02_PLANEJADOR_DE_BUSCAS.md).
